-- Linux Unity premake module
local platform = {}

platform.akName = "Linux"

function platform.GetUnityPlatformName(platformName, cfgplatforms)
    return platformName, cfgplatforms
end

function platform.setupTargetAndLibDir(baseTargetDir)
    libdirs(wwiseSDKEnv .. "/Linux_%{cfg.platform}/%{cfg.buildcfg}/lib")
end

function platform.platformSpecificConfiguration()
    linkgroups 'On'

    defines
    {
        "AK_PLATFORM_SPECIFIC_STUBS"
    }

    -- Link Itanium C++ ABI symbols as we're building with -nostdlib++
    links {
        "supc++"
    }

    filter "Profile* or Release*"
        postbuildcommands ("strip " .. "%{cfg.buildtarget.abspath}")


end

return platform
